#pragma once
#include <vector>
#include <iostream>
#include <string>

using namespace std;

class SequenceMap{
public:
  SequenceMap()=default;
  SequenceMap(const SequenceMap &rhs)=default;
  SequenceMap(SequenceMap&& rhs)=default;
  SequenceMap& operator=(const SequenceMap &rhs)=default;
  SequenceMap& operator=(SequenceMap &&rhs)=default;
  ~SequenceMap()=default;

  SequenceMap(const string &a_rec_seq, const string &an_enz_acro){
    recognition_sequence_ = a_rec_seq;
    enzyme_acronyms_.push_back(an_enz_acro);
  }

  bool operator<(const SequenceMap &rhs)const{
    return this->recognition_sequence_ < rhs.recognition_sequence_;
  }

  friend std::ostream &operator<<(std::ostream &out, const SequenceMap &some_sequence_map){
    if(some_sequence_map.enzyme_acronyms_.size()==0){
      out << "Not Found";
    }
    for(int i = 0; i < some_sequence_map.enzyme_acronyms_.size(); i++){
      out << some_sequence_map.enzyme_acronyms_[i] << " ";
    }
    return out;
  }

//CHECK FOR DUPLICATES
  void Merge(const SequenceMap &other_sequence){
    for(int i = 0; i < other_sequence.enzyme_acronyms_.size(); i++){
      for(int j = 0; j < this->enzyme_acronyms_.size(); j++){
        if(other_sequence.enzyme_acronyms_[i] != this->enzyme_acronyms_[j]){
          this->enzyme_acronyms_.push_back(other_sequence.enzyme_acronyms_[i]);
        }
      }
    }
    }

  string getSeq(){
    return recognition_sequence_;
  }

private:
  string recognition_sequence_;
  vector<string> enzyme_acronyms_;
};

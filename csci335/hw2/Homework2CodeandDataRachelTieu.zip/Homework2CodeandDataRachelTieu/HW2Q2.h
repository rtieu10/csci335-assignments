//Rachel Tieu
//This program contains the SequenceMap class

#pragma once
#include <vector>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cstdlib>

class SequenceMap{
public:
  //DEFAULT CONSTRUCTOR
  SequenceMap()=default;

  //COPY CONSTRUCTOR
  SequenceMap(const SequenceMap &seq)=default;

  //MOVE ASSIGNMENT OPERATOR
  Sequence& operator=(SequenceMap &&seq)=default;

  //MOVE CONSTRCUTOR
  SequenceMap(SequenceMap &&seq)=default;

  //MOVE ASSIGNMENT
  SequenceMap& operator=(SequenceMap &&seq)=default;

  //DESTRUCTOR
  ~SequenceMap()=default;

  SequenceMap(const string &a_rec_seq, const string &an_enz_acro){
    recognition_sequence_ = a_rec_seq;
    enzyme_acronyms_.push_back(an_enz_acro);
  }

  //DEFAULT ASSIGNMENT OPERATOR (Compiler provides)
  //DEFAULT COPY CONSTRCUTOR (Compiler provides)
  //MOVE CONSTRUCTOR

  bool operator<(const SequenceMap &rhs) const{
    return rhs.recognition_sequence_ > this->recognition_sequence_
  }

//OVERLOADING << OPERATOR
//@param seq: sequence is a SequenceMap object that is passed through
//@post : this function overloads the << operator and prints the vector
  //of sequenes in the seq object
  friend std::ostream &operator<<(std::ostream &out, const SequenceMap &seq){
      if(seq.enzyme_acronyms_.size() == 0){
        out << "";    //what to print here
        return out;
      }
      for(int i = 0; i < seq.enzyme_acronyms_.size(); i++){
        out << seq.enzyme_acronyms_[i];
      }
      return out;
  }

//@param other_sequence: this is a SequenceMap object whose vector we want to
  //merge with the object we are looking at, it iterates through the first vector
  //and pushes everything back
  void Merge(const SequenceMap &other_sequence){
    for(int i = 0; i < other_sequence.enzyme_acronyms_.size(); i++){
      this->enzyme_acronyms_.push_back(other_sequence.enzyme_acronyms_[i]);
    }
  }

// void parser(){   //is this the right signature for a parser ? ?
//   Tree<SequenceMap> a_tree;
//   std::string db_line;
//   std::ifstream fin(rebase210.txt.c_str());
//   while(getline(fin, db_line)){
//     std::string an_enz_acro;
//     std::string a_rec_seq;
//     std::stringstream strstream(db_line);
//     getline(strstream,an_enz_acro, '/');  //a delimiter that parses by the slash
//     an_enz_acro = an_enz_acro;  //saves the parsed part of the strign
//     while(getline(db_line, a_rec_seq)){   // how to grab the rest of the line after delimiter
//       SequenceMap new_sequence_map(a_rec_seq,an_enz_acro);
//       a_tree.insert(new_sequence_map);
//     }
//   }
//
// }






private:
  std::string recognition_sequence_;
  vector<std::string> enzyme_acronyms_;

};

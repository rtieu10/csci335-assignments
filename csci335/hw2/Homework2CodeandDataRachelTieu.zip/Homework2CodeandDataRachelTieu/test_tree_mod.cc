// <Your name>
// Main file for Part2(c) of Homework 2.

#include "avl_tree_modified.h"
// You will have to add #include "sequence_map.h"

#include <iostream>
#include <string>
using namespace std;

namespace {

template <typename TreeType>
void parser(const string &db_filename, TreeType& a_tree){
  //Tree<SequenceMap> a_tree;
   std::string db_line;
   std::string junk;
   std::ifstream fin(db_filename.c_str());

   for(int i = 0; i < 10; i++){ //stores all lines of junk
     getline(fin,junk);
   }

  while(getline(fin,db_line)){
     std::string an_enz_acro;
     std::string a_rec_seq;
     std::stringstream strstream(db_line);
     getline(strstream,an_enz_acro, '/');  //a delimiter that parses by the slash
     //an_enz_acro = an_enz_acro;  //saves the parsed part of the strign
     while(getline(strstream, a_rec_seq,'/')){   // how to grab the rest of the line after delimiter
       if(a_rec_seq[0] != '/'){
         SequenceMap new_sequence_map(a_rec_seq,an_enz_acro);
         a_tree.insert(new_sequence_map);
       }
     }
   }

 }

 // @db_filename: an input database filename.
 // @seq_filename: an input sequences filename.
 // @a_tree: an input tree of the type TreeType. It is assumed to be
 //  empty.

template <typename TreeType>
void TestTree(const string &db_filename, const string &seq_filename, TreeType &a_tree) {
  // Code for running Part2(b)
    parser(db_filename, a_tree);
    


}

}  // namespace

int
main(int argc, char **argv) {
  if (argc != 3) {
    cout << "Usage: " << argv[0] << " <databasefilename> <queryfilename>" << endl;
    return 0;
  }
  const string db_filename(argv[1]);
  const string seq_filename(argv[2]);
  cout << "Input file is " << db_filename << ", and sequences file is " << seq_filename << endl;
  // Note that you will replace AvlTree<int> with AvlTree<SequenceMap>
  AvlTree<int> a_tree;
  TestTree(db_filename, seq_filename, a_tree);

  return 0;
}
